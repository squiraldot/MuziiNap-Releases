/**
 * CoverCraft - E-book Cover Design Store
 * Main JavaScript File
 */

// ==========================================
// Configuration
// ==========================================
const CONFIG = {
  productsJsonPath: 'products.json',
  currency: '₹',
  currencyCode: 'INR'
};

// ==========================================
// Theme Toggle (Dark/Light Mode)
// ==========================================

/**
 * Initialize theme based on localStorage or system preference
 */
function initTheme() {
  const savedTheme = localStorage.getItem('theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme) {
    document.documentElement.setAttribute('data-theme', savedTheme);
  } else if (systemPrefersDark) {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
  }
  
  updateThemeIcon();
}

/**
 * Toggle between light and dark theme
 */
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  
  updateThemeIcon();
}

/**
 * Update the theme toggle icon based on current theme
 */
function updateThemeIcon() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const themeToggles = document.querySelectorAll('.theme-toggle');
  
  themeToggles.forEach(toggle => {
    const sunIcon = toggle.querySelector('.theme-icon-light');
    const moonIcon = toggle.querySelector('.theme-icon-dark');
    
    if (sunIcon && moonIcon) {
      if (currentTheme === 'dark') {
        sunIcon.style.display = 'block';
        moonIcon.style.display = 'none';
      } else {
        sunIcon.style.display = 'none';
        moonIcon.style.display = 'block';
      }
    }
  });
}

/**
 * Initialize theme toggle button event listeners
 */
function initThemeToggle() {
  const themeToggles = document.querySelectorAll('.theme-toggle');
  
  themeToggles.forEach(toggle => {
    toggle.addEventListener('click', toggleTheme);
  });
  
  // Listen for system theme changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (!localStorage.getItem('theme')) {
      document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
      updateThemeIcon();
    }
  });
}

// Initialize theme immediately to prevent flash
initTheme();

// ==========================================
// DOM Elements
// ==========================================
const DOM = {
  navToggle: document.querySelector('.nav-toggle'),
  mobileMenu: document.querySelector('.mobile-menu'),
  productsGrid: document.getElementById('products-grid'),
  featuredProducts: document.getElementById('featured-products'),
  productDetail: document.getElementById('product-detail'),
  contactForm: document.getElementById('contact-form')
};

// ==========================================
// Utility Functions
// ==========================================

/**
 * Get URL parameter by name
 * @param {string} name - Parameter name
 * @returns {string|null} - Parameter value
 */
function getUrlParam(name) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(name);
}

/**
 * Format price with currency symbol
 * @param {string|number} price - Price value
 * @returns {string} - Formatted price
 */
function formatPrice(price) {
  return `${CONFIG.currency}${price}`;
}

/**
 * Create HTML element from string
 * @param {string} html - HTML string
 * @returns {HTMLElement} - Created element
 */
function createElementFromHTML(html) {
  const template = document.createElement('template');
  template.innerHTML = html.trim();
  return template.content.firstChild;
}

/**
 * Show loading spinner
 * @param {HTMLElement} container - Container element
 */
function showLoading(container) {
  if (container) {
    container.innerHTML = `
      <div class="loading">
        <div class="spinner"></div>
      </div>
    `;
  }
}

/**
 * Show error message
 * @param {HTMLElement} container - Container element
 * @param {string} message - Error message
 */
function showError(container, message) {
  if (container) {
    container.innerHTML = `
      <div class="error-message">
        <h2>Oops!</h2>
        <p>${message}</p>
        <a href="products.html" class="btn btn-primary">Browse All Products</a>
      </div>
    `;
  }
}

// ==========================================
// Product Functions
// ==========================================

/**
 * Fetch products from JSON file
 * @returns {Promise<Array>} - Array of products
 */
async function fetchProducts() {
  try {
    const response = await fetch(CONFIG.productsJsonPath);
    if (!response.ok) {
      throw new Error('Failed to load products');
    }
    const products = await response.json();
    return products;
  } catch (error) {
    console.error('Error fetching products:', error);
    throw error;
  }
}

/**
 * Create product card HTML
 * @param {Object} product - Product data
 * @returns {string} - HTML string
 */
function createProductCard(product) {
  return `
    <article class="product-card fade-in">
      <div class="product-card-image">
        <img src="${product.image}" alt="${product.title}" loading="lazy">
        <span class="product-card-badge">Digital</span>
      </div>
      <div class="product-card-content">
        <h3 class="product-card-title">${product.title}</h3>
        <p class="product-card-description">${product.shortDescription}</p>
        <div class="product-card-footer">
          <span class="product-card-price">${formatPrice(product.price)}</span>
          <a href="product.html?id=${product.id}" class="btn btn-primary">View Details</a>
        </div>
      </div>
    </article>
  `;
}

/**
 * Render products grid
 * @param {HTMLElement} container - Container element
 * @param {Array} products - Products array
 * @param {number} limit - Optional limit
 */
function renderProductsGrid(container, products, limit = null) {
  if (!container) return;

  const productsToRender = limit ? products.slice(0, limit) : products;
  
  container.innerHTML = productsToRender.map(createProductCard).join('');
}

/**
 * Load and render all products
 */
async function loadAllProducts() {
  if (!DOM.productsGrid) return;

  showLoading(DOM.productsGrid);

  try {
    const products = await fetchProducts();
    renderProductsGrid(DOM.productsGrid, products);
  } catch (error) {
    showError(DOM.productsGrid, 'Unable to load products. Please try again later.');
  }
}

/**
 * Load and render featured products
 */
async function loadFeaturedProducts() {
  if (!DOM.featuredProducts) return;

  showLoading(DOM.featuredProducts);

  try {
    const products = await fetchProducts();
    renderProductsGrid(DOM.featuredProducts, products, 4);
  } catch (error) {
    showError(DOM.featuredProducts, 'Unable to load products. Please try again later.');
  }
}

/**
 * Create product detail HTML
 * @param {Object} product - Product data
 * @returns {string} - HTML string
 */
function createProductDetail(product) {
  const featuresHTML = product.features
    .map(feature => `<li>${feature}</li>`)
    .join('');

  return `
    <div class="product-detail-grid fade-in">
      <div class="product-detail-image">
        <img src="${product.image}" alt="${product.title}">
      </div>
      <div class="product-detail-content">
        <h1>${product.title}</h1>
        <div class="product-detail-price">
          ${formatPrice(product.price)}
          <span>One-time payment</span>
        </div>
        <p class="product-detail-description">${product.fullDescription}</p>
        <div class="product-features">
          <h3>What's Included:</h3>
          <ul>${featuresHTML}</ul>
        </div>
        <a href="${product.razorpayLink}" class="btn btn-accent btn-lg" target="_blank" rel="noopener">
          🛒 Buy Now - ${formatPrice(product.price)}
        </a>
        <p style="margin-top: 1rem; font-size: 0.875rem; color: var(--text-light);">
          Secure payment via Razorpay. Instant download after payment.
        </p>
      </div>
    </div>
  `;
}

/**
 * Load and render product detail
 */
async function loadProductDetail() {
  if (!DOM.productDetail) return;

  const productId = getUrlParam('id');
  
  if (!productId) {
    showError(DOM.productDetail, 'Product not found. Please select a valid product.');
    return;
  }

  showLoading(DOM.productDetail);

  try {
    const products = await fetchProducts();
    const product = products.find(p => p.id === productId);

    if (!product) {
      showError(DOM.productDetail, 'Product not found. The product you are looking for does not exist.');
      return;
    }

    DOM.productDetail.innerHTML = createProductDetail(product);
    
    // Update page title
    document.title = `${product.title} - CoverCraft`;
    
    // Update meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', product.fullDescription);
    }

  } catch (error) {
    showError(DOM.productDetail, 'Unable to load product details. Please try again later.');
  }
}

// ==========================================
// Navigation Functions
// ==========================================

/**
 * Initialize mobile navigation
 */
function initMobileNav() {
  if (!DOM.navToggle || !DOM.mobileMenu) return;

  DOM.navToggle.addEventListener('click', () => {
    DOM.navToggle.classList.toggle('active');
    DOM.mobileMenu.classList.toggle('active');
  });

  // Close mobile menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav') && DOM.mobileMenu.classList.contains('active')) {
      DOM.navToggle.classList.remove('active');
      DOM.mobileMenu.classList.remove('active');
    }
  });

  // Close mobile menu when clicking a link
  DOM.mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      DOM.navToggle.classList.remove('active');
      DOM.mobileMenu.classList.remove('active');
    });
  });
}

// ==========================================
// Form Functions
// ==========================================

/**
 * Initialize contact form
 */
function initContactForm() {
  if (!DOM.contactForm) return;

  DOM.contactForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const formData = new FormData(DOM.contactForm);
    const data = Object.fromEntries(formData);

    // Show success message (in a real app, you'd send this to a server)
    alert('Thank you for your message! We will get back to you soon.');
    DOM.contactForm.reset();

    // Log form data for demo purposes
    console.log('Form submitted:', data);
  });
}

// ==========================================
// Thank You Page Functions
// ==========================================

/**
 * Initialize thank you page
 */
async function initThankYouPage() {
  const downloadBtn = document.getElementById('download-btn');
  if (!downloadBtn) return;

  const productId = getUrlParam('id');
  
  if (productId) {
    try {
      const products = await fetchProducts();
      const product = products.find(p => p.id === productId);
      
      if (product) {
        downloadBtn.href = product.downloadLink;
        downloadBtn.setAttribute('download', '');
      }
    } catch (error) {
      console.error('Error loading product for download:', error);
    }
  }
}

// ==========================================
// Smooth Scroll
// ==========================================

/**
 * Initialize smooth scrolling for anchor links
 */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
}

// ==========================================
// Header Scroll Effect
// ==========================================

/**
 * Add shadow to header on scroll
 */
function initHeaderScroll() {
  const header = document.querySelector('.header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    if (window.scrollY > 10) {
      header.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
    } else {
      header.style.boxShadow = '0 1px 2px 0 rgba(0, 0, 0, 0.05)';
    }
  });
}

// ==========================================
// Intersection Observer for Animations
// ==========================================

/**
 * Initialize scroll animations
 */
function initScrollAnimations() {
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('fade-in');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Observe elements that should animate on scroll
  document.querySelectorAll('.feature-card, .testimonial-card').forEach(el => {
    observer.observe(el);
  });
}

// ==========================================
// Initialize App
// ==========================================

/**
 * Main initialization function
 */
function init() {
  // Initialize theme toggle
  initThemeToggle();
  
  // Initialize navigation
  initMobileNav();
  initHeaderScroll();
  initSmoothScroll();

  // Initialize page-specific functionality
  loadFeaturedProducts();
  loadAllProducts();
  loadProductDetail();
  initContactForm();
  initThankYouPage();

  // Initialize animations
  initScrollAnimations();

  console.log('CoverCraft initialized successfully!');
}

// Run initialization when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
